@echo off
cd /d "%~dp0"
set /p PHONE=Seu numero com codigo do pais e DDD (exemplo +5531999999999): 
if not exist bin\wacli.exe goto missing
powershell.exe -NoProfile -Command "if ($env:PHONE -notmatch '^\+[0-9]{10,15}$') { exit 1 }; & '.\bin\wacli.exe' --store '.\private\whatsapp' auth --phone $env:PHONE --history-days 1"
pause
exit /b
:missing
echo Execute 1-instalar.cmd primeiro.
pause
