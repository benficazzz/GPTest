﻿$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {
    throw 'Instale Python 3 e Ollama pelos sites python.org e ollama.com, ou atualize o Instalador de Aplicativos da Microsoft para habilitar winget.'
}
if (-not (Get-Command py -ErrorAction SilentlyContinue)) {
    winget install --id Python.Python.3.12 --exact --accept-package-agreements --accept-source-agreements
    if ($LASTEXITCODE -ne 0) { throw 'Instalacao do Python falhou.' }
}
if (-not (Get-Command ollama -ErrorAction SilentlyContinue)) {
    winget install --id Ollama.Ollama --exact --accept-package-agreements --accept-source-agreements
    if ($LASTEXITCODE -ne 0) { throw 'Instalacao do Ollama falhou.' }
}
$env:PATH += ";$env:LOCALAPPDATA\Programs\Ollama;$env:LOCALAPPDATA\Programs\Python\Launcher"
if ($env:PROCESSOR_ARCHITECTURE -ne 'AMD64') { throw 'Este pacote requer Windows x64 (Intel/AMD).' }
New-Item -ItemType Directory -Force bin, downloads, private | Out-Null
# Restrict the WhatsApp keys and message store to the current Windows user.
$owner = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
icacls.exe private /inheritance:r /grant:r "${owner}:(OI)(CI)F" | Out-Null
if ($LASTEXITCODE -ne 0) { throw 'Nao foi possivel proteger a pasta private.' }
$release = 'https://github.com/openclaw/wacli/releases/download/v0.22.0'
$asset = 'wacli_0.22.0_windows_amd64.zip'
Invoke-WebRequest "$release/checksums.txt" -OutFile downloads/checksums.txt -UseBasicParsing
Invoke-WebRequest "$release/$asset" -OutFile "downloads/$asset" -UseBasicParsing
$line = Get-Content downloads/checksums.txt | Where-Object { ($_ -split '\s+')[-1].TrimStart('*') -eq $asset }
if (@($line).Count -ne 1) { throw 'Checksum oficial ausente ou ambiguo.' }
$expected = ($line -split '\s+')[0]
$actual = (Get-FileHash "downloads/$asset" -Algorithm SHA256).Hash
if ($actual -ne $expected) { throw 'Checksum SHA256 incorreto. Instalacao interrompida.' }
Expand-Archive "downloads/$asset" -DestinationPath bin -Force
& .\bin\wacli.exe --version
if ($LASTEXITCODE -ne 0) { throw 'wacli nao executou corretamente.' }
if (-not (Get-Command ollama -ErrorAction SilentlyContinue)) { throw 'Feche esta janela, abra outra e execute o instalador novamente para atualizar o PATH.' }
try { Invoke-RestMethod http://127.0.0.1:11434/api/tags | Out-Null }
catch {
    Start-Process ollama -ArgumentList 'serve' -WindowStyle Hidden
    $ready = $false
    for ($i=0; $i -lt 20; $i++) {
        Start-Sleep -Seconds 1
        try { Invoke-RestMethod http://127.0.0.1:11434/api/tags | Out-Null; $ready=$true; break } catch {}
    }
    if (-not $ready) { throw 'Abra o aplicativo Ollama e tente novamente.' }
}
ollama pull qwen3:4b
if ($LASTEXITCODE -ne 0) { throw 'Download do modelo falhou.' }
Write-Host 'Instalado. Abra 2-vincular.cmd para conectar o WhatsApp neste computador.'
