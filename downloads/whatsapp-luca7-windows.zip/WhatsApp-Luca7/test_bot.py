import contextlib
import io
import json
from pathlib import Path
import sqlite3
import tempfile
import time
import unittest
from unittest.mock import Mock, patch
import bot


class Tests(unittest.TestCase):
    def row(self, **updates):
        r = dict(chat_jid=bot.CONTACT, from_me=0, ts=200, deleted_at=None,
                 revoked=0, deleted_for_me=0, media_type='', text='kl')
        r.update(updates)
        return r

    def test_scope_and_filters(self):
        self.assertTrue(bot.eligible(self.row(), 100))
        for update in [dict(chat_jid='other@g.us'), dict(from_me=1), dict(ts=99),
                       dict(deleted_at=1), dict(revoked=1), dict(deleted_for_me=1),
                       dict(media_type='audio'), dict(text=''), dict(text='[Audio]')]:
            with self.subTest(update=update):
                self.assertFalse(bot.eligible(self.row(**update), 100))

    def test_reply_validation(self):
        self.assertEqual(bot.validate_reply({'action': 'reply', 'text': ' Já é '}), 'Já é')
        for value in [{'action': 'skip', 'text': 'x'}, {'action': 'reply', 'text': ''},
                      {'action': 'reply', 'text': 'x' * 301}, {'action': 'reply', 'text': 42}]:
            self.assertIsNone(bot.validate_reply(value))

    def test_ollama_request_and_skip(self):
        opener = Mock()
        opener.open.return_value = contextlib.closing(io.BytesIO(json.dumps({
            'message': {'content': '{"action":"skip","text":""}'}}).encode()))
        with patch.object(bot.urllib.request, 'build_opener', return_value=opener):
            reply = bot.generate([{'speaker': 'Luca7', 'text': 'ta em casa?'}],
                                 {'style': {}, 'reply_rules': []})
        self.assertIsNone(reply)
        request = opener.open.call_args.args[0]
        self.assertEqual(request.full_url, 'http://127.0.0.1:11434/api/chat')
        payload = json.loads(request.data)
        self.assertFalse(payload['stream'])
        self.assertEqual(payload['model'], 'qwen3:4b')
        self.assertIn('ta em casa?', payload['messages'][-1]['content'])

    def run_once(self, root, incoming_id='new', generate_text='Já é'):
        dbpath = root / 'private' / 'whatsapp' / 'wacli.db'
        inserted = False

        def insert(_):
            nonlocal inserted
            if not inserted:
                inserted = True
                with sqlite3.connect(dbpath) as c:
                    c.execute('INSERT INTO messages(chat_jid,msg_id,ts,from_me,text) '
                              'VALUES (?,?,?,?,?)',
                              (bot.CONTACT, incoming_id, int(time.time()), 0, 'kl'))

        proc = Mock()
        proc.poll.side_effect = [None, 0, 0]
        cli = Mock(side_effect=[{'authenticated': True}, {'sent': True}])
        opener = Mock()
        opener.open.return_value = contextlib.closing(io.BytesIO(
            json.dumps({'models': [{'name': bot.MODEL}]}).encode()))
        with patch.object(bot, 'ROOT', root), patch.object(bot, 'cli', cli), \
             patch.object(bot, 'generate', return_value=generate_text), \
             patch.object(bot.subprocess, 'Popen', return_value=proc), \
             patch.object(bot.time, 'sleep', side_effect=insert), \
             patch.object(bot.urllib.request, 'build_opener', return_value=opener), \
             patch('sys.argv', ['bot.py', '--send']), \
             contextlib.redirect_stdout(io.StringIO()):
            with self.assertRaisesRegex(RuntimeError, 'Sincronização parou'):
                bot.main()
        return cli

    def test_send_and_duplicate_reservation(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / 'private' / 'whatsapp').mkdir(parents=True)
            (root / 'perfil.json').write_text('{"style":{},"reply_rules":[]}')
            db = root / 'private' / 'whatsapp' / 'wacli.db'
            with sqlite3.connect(db) as c:
                c.execute('CREATE TABLE messages(rowid INTEGER PRIMARY KEY, chat_jid TEXT, '
                          'msg_id TEXT, ts INTEGER, from_me INTEGER, text TEXT, '
                          'deleted_at INTEGER DEFAULT NULL, revoked INTEGER DEFAULT 0, '
                          'deleted_for_me INTEGER DEFAULT 0, media_type TEXT DEFAULT "")')
                c.execute('INSERT INTO messages(chat_jid,msg_id,ts,from_me,text) '
                          'VALUES (?,?,?,?,?)', (bot.CONTACT, 'old', 1, 0, 'old message'))
            calls = self.run_once(root)
            self.assertEqual(calls.call_count, 2)
            self.assertEqual(calls.call_args.args[-3:], (bot.CONTACT, '--message', 'Já é'))
            with sqlite3.connect(root / 'private' / 'processed.sqlite') as c:
                self.assertEqual(c.execute('SELECT id,status FROM handled').fetchall(), [('new', 'sent')])
            # Simulate the same message being imported again in a later sync.
            calls = self.run_once(root)
            self.assertEqual(calls.call_count, 1)  # Auth check only; no repeated send.


if __name__ == '__main__':
    unittest.main()
