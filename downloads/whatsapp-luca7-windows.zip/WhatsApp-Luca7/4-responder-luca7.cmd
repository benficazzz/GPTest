@echo off
cd /d "%~dp0"
echo Este modo envia respostas automaticamente SOMENTE para Luca7.
echo Mantenha a janela aberta. Ctrl+C para parar.
set PYTHONIOENCODING=utf-8
py -3 bot.py --send
pause
