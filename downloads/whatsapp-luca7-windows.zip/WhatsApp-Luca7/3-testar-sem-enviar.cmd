@echo off
cd /d "%~dp0"
set PYTHONIOENCODING=utf-8
py -3 bot.py
pause
