# WhatsApp local: Luca7

Pacote para Windows 10/11 x64, Python 3 e Ollama. Sem assinatura ou chave de API. Requer alguns GB de download e espaço livre; a velocidade com 16 GB de RAM depende do processador/GPU e dos outros programas abertos.

## Instalar e testar

1. Extraia o ZIP em uma pasta local privada, por exemplo `C:\WhatsApp-Luca7`. Evite pasta compartilhada, Git ou OneDrive.
2. Abra `1-instalar.cmd`. Ele usa o winget para instalar Python/Ollama se necessário, baixa o wacli 0.22.0 para Windows, verifica o SHA256 oficial e baixa `qwen3:4b`. Se o Windows solicitar uma ação, leia e conclua a instalação. Se o instalador pedir para reabrir, abra-o novamente.
3. Abra `2-vincular.cmd`, informe seu número com `+55` e DDD e use o código mostrado em WhatsApp → Aparelhos conectados → Conectar um aparelho → Conectar com número de telefone. É uma nova vinculação no seu Windows. Aguarde a sincronização inicial terminar; se continuar recebendo histórico por muito tempo, encerre com Ctrl+C depois de aparecer conectado.
4. Abra `3-testar-sem-enviar.cmd`. Peça ao Luca7 que envie uma **nova mensagem de texto**. A sugestão aparecerá nesta janela, sem envio. O primeiro carregamento do modelo pode demorar.
5. Feche o teste com Ctrl+C. Abra `4-responder-luca7.cmd` para ativar os envios. Peça uma nova mensagem ao Luca7; mensagens antigas e as recebidas durante a prévia não são reenviadas automaticamente.

O PC precisa ficar ligado, sem suspender, com internet, Ollama aberto e a janela do bot ativa. Este pacote não instala tarefa de inicialização nem serviço permanente. Fechar a janela ou usar Ctrl+C encerra a automação. Não execute a prévia e o envio ao mesmo tempo.

## Comportamento

- Destinatário fixo: apenas Luca7, número terminado em 7369; grupos e outros contatos ficam fora. `bot.py` contém a identidade exata já conferida.
- Usa o perfil de escrita em `perfil.json`, elaborado a partir de 117 mensagens de 12–20/10/2026; não inclui o histórico completo.
- Só considera mensagens recebidas depois de iniciar o processo, sem responder ao histórico antigo sincronizado. Algumas mensagens podem ser ignoradas na passagem de um modo para outro.
- Responde textos curtos. Áudios, imagens, documentos e figurinhas não são interpretados. Se uma mídia encerrar a sequência, o bot aguarda.
- Perguntas que dependem de sua localização, agenda ou compromissos devem ser deixadas para você. O modelo decide quando aguardar: essa decisão pode falhar, especialmente em um modelo pequeno. Valide a prévia antes de ativar.
- Aguarda alguns segundos para juntar mensagens. Se você responder manualmente enquanto a sugestão é gerada, a sugestão é descartada quando sua mensagem já estiver sincronizada. Existe uma pequena janela de corrida entre sincronização e envio.
- Reserva cada resposta antes de tentar enviar e para em falhas, sem repetir automaticamente um envio incerto. Isso evita duplicações, mas uma resposta pode ficar sem envio após falha. Confira no WhatsApp antes de reiniciar.
- O modelo roda em `127.0.0.1`; este programa não manda o histórico para uma API externa. O WhatsApp continua usando sua própria rede. Não exponha a porta do Ollama à internet.

## Dados e diagnóstico

`private` contém sessão do WhatsApp, mensagens, controle de duplicações e `sync.log`, que pode conter identificadores sensíveis. O instalador restringe essa pasta ao seu usuário do Windows. Nunca compartilhe essa pasta nem publique o ambiente com uma sessão pessoal se outras pessoas tiverem acesso à cópia.

Para desconectar, pare o bot e remova o dispositivo no WhatsApp do celular. Você pode apagar `private` depois de desconectar, mas perderá sessão, histórico local e controle de duplicações. Não compartilhe códigos de vinculação.

Se parar, leia a mensagem na janela. Erros de autenticação exigem nova vinculação; falhas de Ollama exigem abrir o aplicativo e confirmar `ollama list`. Para diagnóstico local:

```
bin\wacli.exe --store private\whatsapp doctor --json
```

Use apenas em sua própria conta. wacli é um cliente não oficial baseado no WhatsApp Web, sem afiliação à Meta.

## Validação deste pacote

A lógica de seleção de destinatário, validação de resposta, descarte de mensagens antigas/mídia e prevenção de repetição foi testada em Linux com dados sintéticos e serviços simulados. A instalação Windows, a execução do modelo e o envio automático neste PC ainda precisam ser validados pelos passos acima. Nenhuma resposta automática foi ativada na nuvem.

Fontes: https://github.com/openclaw/wacli — https://ollama.com — skill de referência: https://github.com/openclaw/openclaw/blob/v2026.2.9/skills/wacli/SKILL.md
